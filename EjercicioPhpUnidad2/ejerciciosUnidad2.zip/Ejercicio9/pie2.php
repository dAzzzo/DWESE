<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pie 2</title>
</head>
<body>

<footer>
    <p>&copy; 2023 DWESE. Todos los derechos reservados.</p>
    <p>Este es el pie 2</p>
    <address>
        Póngase en contacto con nosotros en <a href="DAWESE@gmail.com">DAWESE@gmail.com</a>
    </address>
</footer>
    
    
</body>
</html>