<?php 

//Creamos un array asociativo para el encabezado
$ListaEncabezado = [
    "0" => "encabezado1",
    "1" => "encabezado2",
    "2" => "encabezado3"
];

//Creamos un array asociativo para el cuerpo
$ListaCuerpo = [
    "0" => "cuerpo1",
    "1" => "cuerpo2",
    "2" => "cuerpo3"
];

//Creamos un array asociativo para el pie
$ListaPie = [
    "0" => "pie1",
    "1" => "pie2",
    "2" => "pie3"
];

//Creamos un array asociativo para el estilo
$ListaEstilo = [
    "0" => "estilo1",
    "1" => "estilo2",
    "2" => "estilo3"
];

?>