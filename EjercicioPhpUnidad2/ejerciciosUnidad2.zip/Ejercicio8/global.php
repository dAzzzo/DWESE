<?php

 //Creamos un array asociativo con el número de la carta
 $nombre_carta = array(
    "0" => "as",
    "1" => "2",
    "2" => "3",
    "3" => "4",
    "4" => "5",
    "5" => "6",
    "6" => "7",
    "7" => "8",
    "8" => "9",
    "9" => "10",
    "10" => "J",
    "11" => "Q",
    "12" => "K"

);


 //También hay que hacerlo del array llamado $nombre_palo 
 $nombre_palo = [
    "0" => "Corazones",
    "1" => "Picas",
    "2" => "Treboles",
    "3" => "Diamantes"
];
?>